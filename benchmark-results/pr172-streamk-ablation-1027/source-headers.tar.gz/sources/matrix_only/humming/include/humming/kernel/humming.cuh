#pragma once

#include <humming/scheduler.cuh>
#include <humming/utils/all.cuh>

#include <humming/arith/epilogue_arith.cuh>
#include <humming/arith/mainloop_arith.cuh>

#include <humming/epilogue/pipeline.cuh>
#include <humming/memory/g2s_pipeline.cuh>
#include <humming/memory/s2r_pipeline.cuh>
#include <humming/mma/all.cuh>

#include <humming/datatype/dequant.cuh>


template <bool kUseTma>
class KernelTensorParamType {
public:
  using Type = std::conditional_t<kUseTma, CUtensorMap const, void *const>;
};

CUDA_INLINE const void *param_to_ptr(const CUtensorMap &x) { return &x; }
CUDA_INLINE const void *param_to_ptr(void *const &x) { return x; }


template <
    class MmaOpClass,
    class ProblemShape, class BlockShape, class WarpShape, class PadShape,
    class ElementA, class ElementQB, class ElementC, class ElementBS,
    class LayerConfig, class ComputeConfig, class TuningConfig>
__global__ __launch_bounds__(TuningConfig::kNumThreads, TuningConfig::kNumCtasPerSm) void humming(
    const __grid_constant__ typename KernelTensorParamType<TuningConfig::kUseTmaA>::Type A,
    const __grid_constant__ typename KernelTensorParamType<TuningConfig::kUseTmaB>::Type B,
    const __grid_constant__ typename KernelTensorParamType<TuningConfig::kUseTmaC>::Type C,
    const __grid_constant__ typename KernelTensorParamType<TuningConfig::kUseTmaAS>::Type AS,
    const __grid_constant__ typename KernelTensorParamType<TuningConfig::kUseTmaAS2>::Type AS2,
    const __grid_constant__ typename KernelTensorParamType<TuningConfig::kUseTmaBS>::Type BS,
    const __grid_constant__ typename KernelTensorParamType<TuningConfig::kUseTmaBZP>::Type BZP,
    const __grid_constant__ typename KernelTensorParamType<TuningConfig::kUseTmaBias>::Type Bias,
    const __grid_constant__ typename KernelTensorParamType<TuningConfig::kUseTmaBS2>::Type BS2,
    const uint32_t *sorted_ids_ptr,
    const uint32_t *expert_ids_ptr,
    const uint32_t *num_tokens_padded_ptr,
    const uint32_t *expert_layout_ptr,
    CUtensorMap *tensor_map_buffer,
    int32_t *locks,
    uint32_t shape_m,
    uint32_t top_k,
    bool use_int64_expert_layout) {

  uint64_t debug_start_clock = debug_kernel_timer_start();
  constexpr uint32_t kNumThreads = TuningConfig::kNumThreads;
  constexpr uint32_t kNumStages = TuningConfig::kNumStages;
  constexpr bool kUsePdl = TuningConfig::kUsePdl;

  using SharedStorage = SharedStorage<
      MmaOpClass, BlockShape, WarpShape, ElementA, ElementQB, ElementBS,
      LayerConfig, ComputeConfig, TuningConfig>;
  using Ctx = KernelContext<
      MmaOpClass, ProblemShape, BlockShape, WarpShape, PadShape,
      ElementA, ElementQB, ElementC, ElementBS,
      LayerConfig, ComputeConfig, TuningConfig>;
  using Scheduler = Scheduler<Ctx>;
  using ProducerPipeline = ProducerPipeline<Ctx>;
  using ConsumerPipeline = ConsumerPipeline<Ctx>;
  using MainloopArithmetic = MainloopArithmetic<Ctx>;
  using EpilogueArithmetic = EpilogueArithmetic<Ctx>;
  using MMA = Mma<Ctx, MainloopArithmetic>;
  using Epilogue = EpiloguePipeline<Ctx, MMA, EpilogueArithmetic>;
  using S2RMemoryPipeline = S2RMemoryPipeline<Ctx, MMA, Epilogue>;

  extern __shared__ int4 shared_memory[];
  auto &smem = *reinterpret_cast<SharedStorage *>(shared_memory);

  const KernelParams params{
      shape_m, top_k, use_int64_expert_layout,
      param_to_ptr(A), param_to_ptr(B), param_to_ptr(AS), param_to_ptr(AS2), param_to_ptr(BS),
      param_to_ptr(BZP), param_to_ptr(Bias), param_to_ptr(C), param_to_ptr(BS2),
      sorted_ids_ptr, expert_ids_ptr, num_tokens_padded_ptr, expert_layout_ptr,
      tensor_map_buffer, locks};
  auto ctx = Ctx(smem, params);

  auto scheduler = Scheduler(ctx);
  auto mainloop_arith = MainloopArithmetic();
  auto epilogue_arith = EpilogueArithmetic();
  auto mma = MMA(ctx, mainloop_arith);
  auto epilogue = Epilogue(ctx, epilogue_arith);
  auto producer = ProducerPipeline(ctx);
  auto consumer = ConsumerPipeline(ctx);
  auto s2r_pipe = S2RMemoryPipeline(ctx, mma, epilogue);

  producer.init_mbarrier();
  mbarrier_init_sync<((TuningConfig::kMultiCastSizeA * TuningConfig::kMultiCastSizeB) > 1)>();

  bool pdl_waited = false;
  while (scheduler.get_next_block()) {
    debug_kernel_timeout_check(debug_start_clock);
    mma.zero_accum();
    __syncthreads();

    uint32_t &slice_iters = scheduler.slice_iters;
    constexpr uint32_t kStaticSliceIters = ProblemShape::K / BlockShape::K;
    const uint32_t num_slice_iters = Ctx::kUseStreamK ? slice_iters : kStaticSliceIters;
    producer.seek(scheduler.expert_id, scheduler.m_block_id, scheduler.n_block_id, scheduler.k_block_id, scheduler.current_shape_m, scheduler.m_offset);
    s2r_pipe.seek(scheduler.m_offset);
    if constexpr (Ctx::kUseTmaA) producer.prefetch_stage();
    epilogue.seek(scheduler.expert_id, scheduler.m_block_id, scheduler.n_block_id, scheduler.current_shape_m, scheduler.m_offset);
    epilogue.set_streamk_state(scheduler.slice_count, scheduler.slice_id, scheduler.locks_offset);

    if constexpr (TuningConfig::kUseTmaC) {
      tma_wait_store_group<0, true>();
      __syncthreads();
    }
    if constexpr (kUsePdl) {
      if (!pdl_waited) {
        griddepcontrol_wait();
        if (threadIdx.x == 0) griddepcontrol_launch_dependents();
        pdl_waited = true;
      }
    }
    producer.template load_stage<true, true>(0);
    unroll_for<1, MAX(kNumStages - 1, 2), TuningConfig::kProducerStageUnroll>([&](uint32_t stage_id) {
      producer.load_stage(stage_id, stage_id < num_slice_iters);
    });

    consumer.template wait_stage<true>(kNumStages);
    s2r_pipe.template load_stage_iter<true>(0, 0);
    mma.transform_b(0, 0);

    auto consume_stage = [&](uint32_t stage_id, uint32_t slice_iter) {
      debug_kernel_timeout_check(debug_start_clock);
      const uint32_t remaining_iters = num_slice_iters - slice_iter;
      if (remaining_iters == 1) producer.load_channel();
      PRAGMA_UNROLL
      for (uint32_t warp_iter_id = 0; warp_iter_id < Ctx::kWarpIters; warp_iter_id++) {
        constexpr bool kOverlapBDequant = [] {
          if constexpr (Ctx::kUseWgmma) return MMA::kOverlapBDequant;
          else return false;
        }();
        if constexpr (kOverlapBDequant) {
          if (warp_iter_id % 2 == 0) {
            // Prepare the other RS buffer while this fragment is in flight.
            mma.issue(stage_id, warp_iter_id);
            s2r_pipe.load_stage_iter(stage_id, warp_iter_id + 1);
            mma.transform_b(1, warp_iter_id + 1);
            mma.wait_and_promote(stage_id, warp_iter_id);
            mma.preserve_rs_input(warp_iter_id % 2);
            if (warp_iter_id == Ctx::kWarpIters - 2) {
              __syncthreads();
              if constexpr (kNumStages > 2)
                producer.load_stage(stage_id + kNumStages - 1, remaining_iters >= kNumStages);
            }
            continue;
          }
        }
        if constexpr (Ctx::kWgmmaSplitIssueWait) {
          mma.issue(stage_id, warp_iter_id);
          if constexpr (Ctx::kWarpIters == 1) {
            // Refill a different stage; the current WGMMA stage stays live until wait.
            __syncthreads();
            if constexpr (kNumStages > 2)
              producer.load_stage(stage_id + kNumStages - 1, remaining_iters >= kNumStages);
          }
          if (warp_iter_id == Ctx::kWarpIters - 1 && remaining_iters > 1)
            consumer.wait_stage((stage_id + 1) % kNumStages);
          const bool use_late_scale_prefetch = Ctx::kUseWgmmaLateScalePrefetch && warp_iter_id == Ctx::kWarpIters - 1;
          if (use_late_scale_prefetch)
            s2r_pipe.load_stage_iter_data(stage_id, warp_iter_id + 1);
          else
            s2r_pipe.load_stage_iter(stage_id, warp_iter_id + 1);
          mma.wait_and_promote(stage_id, warp_iter_id);
          if (use_late_scale_prefetch)
            s2r_pipe.load_stage_iter_scales(stage_id, warp_iter_id + 1);

          if (Ctx::kWarpIters > 1 && warp_iter_id == Ctx::kWarpIters - 2) {
            __syncthreads();
            if constexpr (kNumStages > 2)
              producer.load_stage(stage_id + kNumStages - 1, remaining_iters >= kNumStages);
          }
        } else {
          if constexpr (Ctx::kWarpIters == 1) {
            mma.run(stage_id, warp_iter_id);
            __syncthreads();
            if constexpr (kNumStages > 2) {
              producer.load_stage(stage_id + kNumStages - 1, remaining_iters >= kNumStages);
            }
          }
          if (warp_iter_id == Ctx::kWarpIters - 1 && remaining_iters > 1) {
            consumer.wait_stage((stage_id + 1) % kNumStages);
          }
          constexpr bool kDeferScalePrefetch = Ctx::kUseWgmma && ElementA::kBits < 16 &&
                                               (Ctx::kPreserveASForPromotion || Ctx::kPreserveBSForPromotion);
          if constexpr (kDeferScalePrefetch) {
            s2r_pipe.load_stage_iter_data(stage_id, warp_iter_id + 1);
            if constexpr (Ctx::kWarpIters > 1) mma.run(stage_id, warp_iter_id);
            s2r_pipe.load_stage_iter_scales(stage_id, warp_iter_id + 1);
          } else {
            s2r_pipe.load_stage_iter(stage_id, warp_iter_id + 1);
            if constexpr (Ctx::kWarpIters > 1) mma.run(stage_id, warp_iter_id);
          }
          if (Ctx::kWarpIters > 1 && warp_iter_id == Ctx::kWarpIters - 2) {
            __syncthreads();
            if constexpr (kNumStages > 2) {
              producer.load_stage(stage_id + kNumStages - 1, remaining_iters >= kNumStages);
            }
          }
        }
        mma.transform_b(
            ((warp_iter_id + 1) % Ctx::kWarpIters) % 2,
            (warp_iter_id + 1) % Ctx::kWarpIters);
      }
      if constexpr (kNumStages == 2) {
        producer.load_stage(stage_id, remaining_iters > kNumStages);
      }
    };

    const uint32_t num_full_stage_cycles = num_slice_iters / kNumStages;
    for (uint32_t cycle_id = 0; cycle_id < num_full_stage_cycles; cycle_id++) {
      unroll_for<0, kNumStages, TuningConfig::kConsumerStageUnroll>([&](uint32_t stage_id) {
        consume_stage(stage_id, cycle_id * kNumStages + stage_id);
      });
    }
    const uint32_t tail_stage_iters = num_slice_iters % kNumStages;
    unroll_for<0, kNumStages, TuningConfig::kConsumerStageUnroll>([&](uint32_t stage_id) {
      if (stage_id < tail_stage_iters) {
        consume_stage(stage_id, num_full_stage_cycles * kNumStages + stage_id);
      }
    });

    consumer.wait_channel();
    s2r_pipe.load_channel(scheduler.slice_id);
    __syncthreads();
    epilogue.call(mma.final_regs_c_as_ptr());
  }

  __syncthreads();
  if constexpr (TuningConfig::kMultiCastSizeA * TuningConfig::kMultiCastSizeB > 1) {
    asm volatile("barrier.cluster.arrive;\n");
    asm volatile("barrier.cluster.wait;\n");
  }
};
