#pragma once

#include <cooperative_groups.h>
#include <cuda_awbarrier_primitives.h>
#include <humming/memory/g2s_loader/loader_a.cuh>
#include <humming/memory/g2s_loader/loader_as.cuh>
#include <humming/memory/g2s_loader/loader_b.cuh>
#include <humming/memory/g2s_loader/loader_bias.cuh>
#include <humming/memory/g2s_loader/loader_bs.cuh>
#include <humming/memory/g2s_loader/loader_bs2.cuh>
#include <humming/memory/g2s_loader/loader_bzp.cuh>
#include <humming/utils/all.cuh>


template <class Ctx, bool kEnableContinuousRing = false>
class ProducerPipeline {
private:
  using SharedStorage = typename Ctx::SharedStorage;
  using ElementA = typename Ctx::ElementA;

  static constexpr uint32_t kNumThreads = Ctx::kNumThreads;
  static constexpr uint32_t kNumLoadThreads = Ctx::kNumLoadThreads;
  static constexpr uint32_t kNumMathThreads = Ctx::kNumMathThreads;

  static constexpr bool kUseMBarrier = Ctx::kUseMBarrier;
  static constexpr bool kUseCpAsync = Ctx::kUseCpAsync;
  static constexpr bool kUseWarpSpec = Ctx::kUseWarpSpec;
  static constexpr bool kUseTma = Ctx::kUseTma;
  static constexpr bool kUseTmaA = Ctx::kUseTmaA;
  static constexpr bool kUseTmaAS = Ctx::kUseTmaAS && !Ctx::kIsIndexedGemm && !Ctx::kIsTensorInputScale;
  static constexpr bool kUseTmaAS2 = Ctx::kUseTmaAS2 && !Ctx::kIsIndexedGemm && !Ctx::kIsTensorInputScale2;
  static constexpr bool kUseTmaB = Ctx::kUseTmaB;
  static constexpr bool kUseTmaBS = Ctx::kUseTmaBS;
  static constexpr bool kUseTmaBS2 = Ctx::kUseTmaBS2;
  static constexpr bool kUseTmaBZP = Ctx::kUseTmaBZP;
  static constexpr bool kUseTmaBias = Ctx::kUseTmaBias;

  static constexpr bool kHasInputScale = Ctx::kHasInputScale;
  static constexpr bool kHasInputScale2 = Ctx::kHasInputScale2;
  static constexpr bool kIsTensorInputScale = Ctx::kIsTensorInputScale;
  static constexpr bool kIsTensorInputScale2 = Ctx::kIsTensorInputScale2;
  static constexpr bool kIsChannelInputScale = kHasInputScale && !Ctx::kIsGroupInputScale && !kIsTensorInputScale;
  static constexpr bool kIsChannelInputScale2 = !Ctx::kUseUmma && kHasInputScale2 && !kIsTensorInputScale2;
  static constexpr bool kIsGroupInputScale = kHasInputScale && Ctx::kIsGroupInputScale;
  static constexpr bool kIsChannelWeightScale = Ctx::kIsChannelWeightScale;
  static constexpr bool kIsChannelWeightScale2 = Ctx::kIsChannelWeightScale2;
  static constexpr bool kIsGroupWeightScale = Ctx::kIsGroupWeightScale;
  static constexpr bool kIsBlockWeightScale = Ctx::kIsBlockWeightScale;
  static constexpr bool kHasZeroPoint = Ctx::kHasZeroPoint;
  static constexpr bool kHasBias = Ctx::kHasBias;
  static constexpr bool kHasChannelData =
      kIsChannelInputScale || kIsChannelInputScale2 || kIsChannelWeightScale ||
      kIsChannelWeightScale2 || kHasBias;

  static constexpr uint32_t kNumStages = Ctx::kNumStages;

  template <bool kIsFirst = false>
  static constexpr uint2 get_stage_load_bytes() {
    uint32_t tma_load_bytes = 0;
    uint32_t legacy_load_bytes = 0;

    if constexpr (kUseTmaA) tma_load_bytes += SharedStorage::kStageBytesA;
    else legacy_load_bytes += SharedStorage::kStageBytesA;

    if constexpr (kUseTmaB) tma_load_bytes += SharedStorage::kStageLoadBytesB;
    else legacy_load_bytes += SharedStorage::kStageLoadBytesB;

    if constexpr (kIsGroupInputScale) {
      if constexpr (kUseTmaAS) tma_load_bytes += SharedStorage::kStageTmaBytesAS;
      else legacy_load_bytes += SharedStorage::kStageBytesAS;
    }

    if constexpr (kIsGroupWeightScale || kIsBlockWeightScale) {
      if constexpr (kUseTmaBS) tma_load_bytes += SharedStorage::kStageBytesBS;
      else legacy_load_bytes += SharedStorage::kStageBytesBS;
    }

    if constexpr (kHasZeroPoint && (kIsGroupWeightScale || kIsFirst)) {
      constexpr uint32_t zero_point_bytes = kIsChannelWeightScale ? SharedStorage::kChannelBytesBZP : SharedStorage::kStageBytesBZP;
      if constexpr (kUseTmaBZP) tma_load_bytes += zero_point_bytes;
      else legacy_load_bytes += zero_point_bytes;
    }

    return {tma_load_bytes, legacy_load_bytes};
  }

  static constexpr uint2 get_channel_load_bytes() {
    uint32_t tma_load_bytes = 0;
    uint32_t legacy_load_bytes = 0;

    if constexpr (kIsChannelInputScale) {
      if constexpr (kUseTmaAS) tma_load_bytes += SharedStorage::kChannelBytesAS;
      else legacy_load_bytes += SharedStorage::kChannelBytesAS;
    }
    if constexpr (kIsChannelInputScale2) {
      if constexpr (kUseTmaAS2) {
        tma_load_bytes += SharedStorage::kChannelBytesAS;
      } else {
        legacy_load_bytes += SharedStorage::kChannelBytesAS;
      }
    }

    if constexpr (kIsChannelWeightScale) {
      if constexpr (kUseTmaBS) tma_load_bytes += SharedStorage::kChannelBytesBS;
      else legacy_load_bytes += SharedStorage::kChannelBytesBS;
    }

    if constexpr (kIsChannelWeightScale2) {
      if constexpr (kUseTmaBS2) tma_load_bytes += SharedStorage::kChannelBytesBS2;
      else legacy_load_bytes += SharedStorage::kChannelBytesBS2;
    }

    if constexpr (kHasBias) {
      if constexpr (kUseTmaBias) tma_load_bytes += SharedStorage::kBiasBytes;
      else legacy_load_bytes += SharedStorage::kBiasBytes;
    }

    return {tma_load_bytes, legacy_load_bytes};
  }

public:
  static constexpr bool kHasFirstStageTmaMBarrier = get_stage_load_bytes<true>().x > 0;
  static constexpr bool kHasFirstStageCpAsyncMBarrier = get_stage_load_bytes<true>().y > 0;
  static constexpr bool kHasStageTmaMBarrier = get_stage_load_bytes().x > 0;
  static constexpr bool kHasStageCpAsyncMBarrier = get_stage_load_bytes().y > 0;
  static constexpr bool kHasChannelTmaMBarrier = get_channel_load_bytes().x > 0;
  static constexpr bool kHasChannelCpAsyncMBarrier = get_channel_load_bytes().y > 0;
  static constexpr bool kHasUniformStageBarriers = kHasFirstStageTmaMBarrier == kHasStageTmaMBarrier && kHasFirstStageCpAsyncMBarrier == kHasStageCpAsyncMBarrier;
  static constexpr bool kUseContinuousRing = kEnableContinuousRing && kUseMBarrier && kHasUniformStageBarriers;
  static constexpr bool kHasTileScopedInputs = kHasChannelData || Ctx::kIsIndexedGemm;
  static constexpr bool kNeedsTileHandshake = !kUseContinuousRing || kHasTileScopedInputs;

  static constexpr uint32_t kMultiCastSizeA = Ctx::kMultiCastSizeA;
  static constexpr uint32_t kMultiCastSizeB = Ctx::kMultiCastSizeB;
  static constexpr uint32_t kMultiCastSize = kMultiCastSizeA * kMultiCastSizeB;

  using LoaderA = G2SMemoryLoaderA<Ctx>;
  using LoaderB = G2SMemoryLoaderB<Ctx>;
  using LoaderAS = G2SMemoryLoaderAS<Ctx>;
  using LoaderAS2 = G2SMemoryLoaderAS<Ctx, true>;
  using LoaderBS = G2SMemoryLoaderBS<Ctx>;
  using LoaderBS2 = G2SMemoryLoaderBS2<Ctx>;
  using LoaderBZP = G2SMemoryLoaderBZP<Ctx>;
  using LoaderBias = G2SMemoryLoaderBias<Ctx>;

  Ctx &ctx;
  LoaderA loader_a;
  LoaderB loader_b;
  LoaderAS loader_as;
  LoaderAS2 loader_as2;
  LoaderBS loader_bs;
  LoaderBS2 loader_bs2;
  LoaderBZP loader_bzp;
  LoaderBias loader_bias;
  uint32_t phase_bits = 0;

private:
  uint32_t ring_stage = 0;
  uint32_t ring_phase = 1;

public:
  CUDA_INLINE
  ProducerPipeline(Ctx &ctx)
      : ctx(ctx),
        loader_a(ctx),
        loader_b(ctx),
        loader_as(ctx),
        loader_as2(ctx),
        loader_bs(ctx),
        loader_bs2(ctx),
        loader_bzp(ctx),
        loader_bias(ctx) {
    if constexpr (!kUseWarpSpec) {
      if (ctx.load_thread_id() == 0) {
        if constexpr (kUseTmaA) prefetch_tensor_map(ctx.params.a);
        if constexpr (kUseTmaAS) prefetch_tensor_map(ctx.params.as);
        if constexpr (kUseTmaAS2) prefetch_tensor_map(ctx.params.as2);
        if constexpr (kUseTmaB) prefetch_tensor_map(ctx.params.b);
        if constexpr (kUseTmaBS) prefetch_tensor_map(ctx.params.bs);
        if constexpr (kUseTmaBS2) prefetch_tensor_map(ctx.params.bs2);
        if constexpr (kUseTmaBZP) prefetch_tensor_map(ctx.params.bzp);
        if constexpr (kUseTmaBias) prefetch_tensor_map(ctx.params.bias);
      }
      __syncwarp();
    }
  }

  template <uint32_t kStageConsumers = kNumMathThreads, uint32_t kChannelConsumers = kNumMathThreads>
  CUDA_INLINE static void init_mbarrier(Ctx &ctx) {
    if constexpr (kUseMBarrier) {
      uint32_t thread_id = ctx.load_thread_id();
      uint32_t cluster_rank = ctx.cluster_rank();
      auto &smem = ctx.smem;
      uint32_t count;
      if (thread_id < kNumStages) {
        constexpr uint32_t cp_async_thread_count = kHasStageCpAsyncMBarrier ? kNumLoadThreads : 0;
        constexpr uint32_t tma_thread_count = kHasStageTmaMBarrier ? 1 : 0;
        if constexpr (Ctx::kUseUmmaAsyncActivationLoads)
          count = kNumLoadThreads + (kIsGroupInputScale && kUseTmaAS ? 1 : 0);
        else count = Ctx::kUseUmmaCooperativeTma ? 2 : cp_async_thread_count + tma_thread_count;
      } else if (thread_id == kNumStages) {
        constexpr uint32_t cp_async_thread_count = kHasFirstStageCpAsyncMBarrier ? kNumLoadThreads : 0;
        constexpr uint32_t tma_thread_count = kHasFirstStageTmaMBarrier ? 1 : 0;
        count = cp_async_thread_count + tma_thread_count;
      } else if (thread_id == kNumStages + 1) {
        constexpr uint32_t cp_async_thread_count = kHasChannelCpAsyncMBarrier ? kNumLoadThreads : 0;
        constexpr uint32_t tma_thread_count = kHasChannelTmaMBarrier ? 1 : 0;
        count = cp_async_thread_count + tma_thread_count;
      }

      if (thread_id < kNumStages + 2) __mbarrier_init(&smem.load_mbar[thread_id], count);
      uint32_t factor = (kMultiCastSize > 1 && cluster_rank == 0 && thread_id < SharedStorage::kNumMathMbarriers) ? kMultiCastSize : 1;
      if constexpr (Ctx::kUseWarpSpec) {
        if (thread_id < SharedStorage::kNumMathMbarriers) {
          uint32_t consumers = thread_id < kNumStages ? kStageConsumers : kChannelConsumers;
          __mbarrier_init(&smem.math_mbar[thread_id], consumers * factor);
        }
      }
    }
  }

  CUDA_INLINE void init_mbarrier() {
    init_mbarrier(ctx);
  }

  template <bool kShouldAdvance = true, bool kIsFirst = false>
  CUDA_INLINE void load_stage(uint32_t stage_id, bool pred = true) {
    if constexpr (kUseContinuousRing) {
      if (!pred) return;
      stage_id = ring_stage;
    } else stage_id = stage_id % kNumStages;
    auto &smem = ctx.smem;
    if constexpr (Ctx::kUseUmmaAsyncActivationLoads) {
      // All loading threads gather A/AS; only the elected TMA loading thread
      // submits B/BS. Keep their completions separate without halving A bandwidth.
      if (pred) {
        load_weight_stage<kShouldAdvance>(stage_id);
        loader_a.template load<kShouldAdvance>(smem.stages[stage_id].a, &smem.load_mbar[stage_id], stage_id);
        if constexpr (kIsGroupInputScale)
          loader_as.template load<kShouldAdvance>(smem.stages[stage_id].as, &smem.load_mbar[stage_id]);
      }
      commit_cp_async_load<true>(stage_id, pred);
      if constexpr (kIsGroupInputScale && kUseTmaAS)
        if (pred) expect_tma_load<true>(&smem.load_mbar[stage_id], SharedStorage::kStageTmaBytesAS);
      return;
    }

    uint32_t mbar_index = kIsFirst && !kUseContinuousRing ? kNumStages : stage_id;
    constexpr uint2 load_bytes = get_stage_load_bytes<kIsFirst>();
    constexpr bool kHasTmaMBarrier = kIsFirst ? kHasFirstStageTmaMBarrier : kHasStageTmaMBarrier;

    uint64_t *mbar_ptr = nullptr;
    if constexpr (kUseMBarrier) mbar_ptr = &smem.load_mbar[mbar_index];
    if (pred) {
      loader_a.template load<kShouldAdvance>(smem.stages[stage_id].a, mbar_ptr, stage_id);
      loader_b.template load<kShouldAdvance>(smem.stages[stage_id].b, mbar_ptr);
      if constexpr (kIsGroupInputScale) {
        loader_as.template load<kShouldAdvance>(smem.stages[stage_id].as, mbar_ptr);
      };
      if constexpr (kIsGroupWeightScale || kIsBlockWeightScale) {
        loader_bs.template load<kShouldAdvance>(smem.stages[stage_id].bs, mbar_ptr);
      };
      if constexpr (kHasZeroPoint && (kIsGroupWeightScale || kIsFirst)) {
        if constexpr (kIsChannelWeightScale)
          loader_bzp.template load<kShouldAdvance>(smem.bzp_c, mbar_ptr);
        else
          loader_bzp.template load<kShouldAdvance>(smem.stages[stage_id].bzp, mbar_ptr);
      }
    }

    if constexpr (kIsFirst) {
      commit_cp_async_load<kHasFirstStageCpAsyncMBarrier>(mbar_index, pred);
    } else {
      commit_cp_async_load<kHasStageCpAsyncMBarrier>(mbar_index, pred);
    }
    if (pred) expect_tma_load<kHasTmaMBarrier>(mbar_ptr, load_bytes.x);
    if constexpr (kUseContinuousRing) {
      if (++ring_stage == kNumStages) {
        ring_stage = 0;
        ring_phase ^= 1;
      }
    }
  }

  template <bool kShouldAdvance = true>
  CUDA_INLINE void load_weight_stage(uint32_t stage_id) {
    auto &stage = ctx.smem.stages[stage_id];
    constexpr bool kJoinActivation = Ctx::kUseUmmaCooperativeTma && !Ctx::kUseUmmaAsyncActivationLoads;
    auto *weight_mbar = kJoinActivation ? &ctx.smem.load_mbar[stage_id] : &ctx.smem.umma_weight_ready[stage_id];
    loader_b.template load<kShouldAdvance>(stage.b, weight_mbar);
    uint32_t bytes = SharedStorage::kStageLoadBytesB;
    if constexpr (kIsGroupWeightScale || kIsBlockWeightScale) {
      loader_bs.template load<kShouldAdvance, Ctx::kUseUmmaCooperativeTma ? 2 : 1>(stage.bs, weight_mbar);
      bytes += SharedStorage::kStageBytesBS;
    }
    if constexpr (kHasZeroPoint && !kIsChannelWeightScale) {
      loader_bzp.template load<kShouldAdvance>(stage.bzp, weight_mbar);
      bytes += SharedStorage::kStageBytesBZP;
    }
    if constexpr (Ctx::kUseUmmaCooperativeTma) {
      if (ctx.load_thread_id() == 0 && blockIdx.x % Ctx::kUmmaCtaGroupSize == 0) tma_expect_tx(weight_mbar, bytes * 2);
    } else if (ctx.load_thread_id() == 0) tma_expect_tx(weight_mbar, bytes);
  }

  template <bool kShouldAdvance = true>
  CUDA_INLINE void load_activation_stage(uint32_t stage_id) {
    auto &stage = ctx.smem.stages[stage_id];
    auto *activation_mbar = &ctx.smem.load_mbar[stage_id];
    loader_a.template load<kShouldAdvance>(stage.a, activation_mbar, stage_id);
    uint32_t bytes = SharedStorage::kStageBytesA;
    if constexpr (kIsGroupInputScale) {
      if constexpr (Ctx::kUseUmmaSeparateInputScale) {
        auto *scale_mbar = &ctx.smem.umma_input_scale_ready[stage_id];
        loader_as.template load<kShouldAdvance>(stage.as, scale_mbar);
        if (ctx.load_thread_id() == 32) tma_expect_tx(scale_mbar, SharedStorage::kStageTmaBytesAS);
      } else {
        loader_as.template load<kShouldAdvance>(stage.as, activation_mbar);
        bytes += SharedStorage::kStageTmaBytesAS;
      }
    }
    if constexpr (Ctx::kUseUmmaCooperativeTma) {
      if (ctx.load_thread_id() == 32 && blockIdx.x % Ctx::kUmmaCtaGroupSize == 0) tma_expect_tx(activation_mbar, bytes * 2);
    } else if (ctx.load_thread_id() == 32) tma_expect_tx(activation_mbar, bytes);
  }

  CUDA_INLINE void load_channel() {
    auto &smem = ctx.smem;
    uint64_t *channel_mbar_ptr = nullptr;
    constexpr uint2 load_bytes = get_channel_load_bytes();
    if constexpr (kUseMBarrier) channel_mbar_ptr = &smem.load_mbar[kNumStages + 1];
    if constexpr (kIsChannelInputScale) loader_as.load(smem.as_c, channel_mbar_ptr);
    if constexpr (kIsChannelInputScale2) loader_as2.load(smem.as_c, channel_mbar_ptr);
    if constexpr (kIsChannelWeightScale) loader_bs.load(smem.bs_c, channel_mbar_ptr);
    if constexpr (kIsChannelWeightScale2) loader_bs2.load(smem.bs2_c, channel_mbar_ptr);
    if constexpr (kHasBias) loader_bias.load(smem.bias, channel_mbar_ptr);

    if constexpr (load_bytes.x > 0 || load_bytes.y > 0) {
      commit_cp_async_load<kHasChannelCpAsyncMBarrier>(kNumStages + 1);
    }
    expect_tma_load<kHasChannelTmaMBarrier>(channel_mbar_ptr, load_bytes.x);
  }

  CUDA_INLINE void prefetch_stage() {
    loader_a.prefetch_tma();
    loader_b.prefetch_tma();
    loader_as.prefetch_tma();
    loader_as2.prefetch_tma();
    loader_bs.prefetch_tma();
    loader_bs2.prefetch_tma();
    loader_bzp.prefetch_tma();
    loader_bias.prefetch_tma();
  }

  template <bool kHasTmaMBarrier>
  CUDA_INLINE void expect_tma_load(uint64_t *mbar_ptr, uint32_t bytes) {
    if constexpr (kUseMBarrier && kHasTmaMBarrier) {
      if (ctx.load_thread_id() == 0) {
        tma_expect_tx(mbar_ptr, bytes);
      }
    }
  }

  template <bool kHasCpAsyncMBarrier>
  CUDA_INLINE void commit_cp_async_load(uint32_t stage_id, bool pred = true) {
    auto &smem = ctx.smem;
    if constexpr (kUseMBarrier) {
      if (!pred) return;
      if constexpr (kHasCpAsyncMBarrier) {
        cp_async_commit_mbarrier(&smem.load_mbar[stage_id]);
      }
    } else if constexpr (kUseCpAsync) {
      cp_async_commit_group();
    }
  }

  CUDA_INLINE uint32_t get_phase(uint32_t stage_id) {
    return (phase_bits >> stage_id) & 1u;
  }

  CUDA_INLINE void advance_phase(uint32_t stage_id) {
    phase_bits ^= 1u << stage_id;
  }

  CUDA_INLINE void wait_stage(uint32_t stage_id, bool pred = true) {
    if (!pred) return;
    if constexpr (kUseContinuousRing) stage_id = ring_stage;
    const uint32_t phase = kUseContinuousRing ? ring_phase : get_phase(stage_id);
    mbarrier_wait(&ctx.smem.math_mbar[stage_id], phase, "Humming producer waiting for math stage");
    if constexpr (Ctx::kUseWarpSpec) ctx.sync_load_threads();
    if constexpr (!kUseContinuousRing) advance_phase(stage_id);
  }

  CUDA_INLINE void wait_channel() {
    if constexpr (kHasChannelData && kUseMBarrier) {
      mbarrier_wait(&ctx.smem.math_mbar[kNumStages], get_phase(kNumStages), "Humming producer waiting for channel consumer");
      if constexpr (Ctx::kUseWarpSpec) ctx.sync_load_threads();
      advance_phase(kNumStages);
    }
  }

  CUDA_INLINE void wait_math_epilogue() {
    if constexpr (!kNeedsTileHandshake) return;
    mbarrier_wait(&ctx.smem.math_mbar[kNumStages], get_phase(kNumStages), "Humming producer waiting for epilogue");
    if constexpr (Ctx::kUseWarpSpec) ctx.sync_load_threads();
    advance_phase(kNumStages);
  }

  CUDA_INLINE void seek(
      uint32_t expert_id, uint32_t m_block_id, uint32_t n_block_id, uint32_t k_block_id,
      uint32_t current_shape_m, uint32_t m_offset) {
    loader_a.seek(m_block_id, k_block_id, current_shape_m, m_offset);
    loader_b.seek(expert_id, n_block_id, k_block_id);
    if constexpr (kHasInputScale && !kIsTensorInputScale) loader_as.seek(expert_id, m_block_id, k_block_id, current_shape_m, m_offset);
    if constexpr (kIsChannelInputScale2) loader_as2.seek(expert_id, m_block_id, k_block_id, current_shape_m, m_offset);
    loader_bs.seek(expert_id, n_block_id, k_block_id);
    loader_bs2.seek(expert_id, n_block_id);
    loader_bzp.seek(expert_id, n_block_id, k_block_id);
    loader_bias.seek(expert_id, n_block_id);
  }
};


template <class Ctx, bool kUseContinuousRing = false>
class ConsumerPipeline {
private:
  using SharedStorage = typename Ctx::SharedStorage;
  using ElementA = typename Ctx::ElementA;

  static constexpr uint32_t kNumThreads = Ctx::kNumThreads;
  static constexpr uint32_t kNumMathThreads = Ctx::kNumMathThreads;

  static constexpr bool kUseMBarrier = Ctx::kUseMBarrier;
  static constexpr bool kUseCpAsync = Ctx::kUseCpAsync;

  static constexpr bool kHasInputScale = Ctx::kHasInputScale;
  static constexpr bool kHasInputScale2 = Ctx::kHasInputScale2;
  static constexpr bool kIsChannelInputScale = kHasInputScale && !Ctx::kIsGroupInputScale && !Ctx::kIsTensorInputScale;
  static constexpr bool kIsChannelInputScale2 = !Ctx::kUseUmma && kHasInputScale2 && !Ctx::kIsTensorInputScale2;
  static constexpr bool kIsChannelWeightScale = Ctx::kIsChannelWeightScale;
  static constexpr bool kIsChannelWeightScale2 = Ctx::kIsChannelWeightScale2;
  static constexpr bool kHasBias = Ctx::kHasBias;

  static constexpr uint32_t kNumStages = Ctx::kNumStages;
  static constexpr uint32_t kMultiCastSizeA = Ctx::kMultiCastSizeA;
  static constexpr uint32_t kMultiCastSizeB = Ctx::kMultiCastSizeB;
  static constexpr uint32_t kMultiCastSize = kMultiCastSizeA * kMultiCastSizeB;

public:
  static constexpr bool kHasChannelData =
      kIsChannelInputScale || kIsChannelInputScale2 || kIsChannelWeightScale ||
      kIsChannelWeightScale2 || kHasBias;

  Ctx &ctx;
  uint32_t phases[kNumStages + 2] = {0};

private:
  uint32_t ring_stage = 0;
  uint32_t ring_phase = 0;

public:
  CUDA_INLINE uint32_t get_stage_id(uint32_t stage_id) const {
    if constexpr (kUseContinuousRing) return ring_stage;
    else return stage_id;
  }

  CUDA_INLINE
  ConsumerPipeline(Ctx &ctx) : ctx(ctx) {
  }

  template <bool kIsFirst = false>
  CUDA_INLINE void wait_stage(uint32_t stage_id) {
    if constexpr (kUseContinuousRing) {
      const uint32_t next_stage = ring_stage + 1 == kNumStages ? 0 : ring_stage + 1;
      const uint32_t wait_stage = kIsFirst ? ring_stage : next_stage;
      const uint32_t wait_phase = ring_phase ^ (!kIsFirst && wait_stage == 0);
      mbarrier_wait(&ctx.smem.load_mbar[wait_stage], wait_phase, "Humming consumer waiting for ring stage");
      return;
    }
    stage_id = kIsFirst ? kNumStages : (stage_id % kNumStages);
    if constexpr (kUseMBarrier) {
      mbarrier_wait(&ctx.smem.load_mbar[stage_id], phases[stage_id], "Humming consumer waiting for load stage");
      phases[stage_id] ^= 1;
    } else {
      if constexpr (kUseCpAsync) cp_async_wait_group<kNumStages - 2>();
      __syncthreads();
    }
  }

  CUDA_INLINE void wait_channel() {
    if constexpr (kHasChannelData) {
      if constexpr (kUseMBarrier) {
        mbarrier_wait(&ctx.smem.load_mbar[kNumStages + 1], phases[kNumStages + 1], "Humming consumer waiting for channel data");
        phases[kNumStages + 1] ^= 1;
      } else {
        if constexpr (kUseCpAsync) cp_async_wait_group<0>();
        __syncthreads();
      }
    }
  }

  CUDA_INLINE void arrive(uint32_t stage_id) {
    if constexpr (!ProducerPipeline<Ctx, kUseContinuousRing>::kNeedsTileHandshake) {
      if (stage_id == kNumStages) return;
    }
    auto &smem = ctx.smem;
    mbarrier_arrive(&smem.math_mbar[stage_id]);
    if constexpr (kMultiCastSize > 1) {
      if (ctx.cluster_rank() >= 1 && stage_id < SharedStorage::kNumMathMbarriers) {
        void *aa = __cluster_map_shared_rank(&smem.math_mbar[stage_id], 0);
        mbarrier_arrive<true>(aa);
      }
    }
    if constexpr (kUseContinuousRing) {
      if (stage_id < kNumStages && ++ring_stage == kNumStages) {
        ring_stage = 0;
        ring_phase ^= 1;
      }
    }
  }
};
